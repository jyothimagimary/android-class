package com.example.mvc_dvr;

public class CDept {
    int id;
    String dname;
    String dloc;
}
